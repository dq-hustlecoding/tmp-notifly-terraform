exports.handler = async () => {
    console.log('Testing terraformer-generated lambda')
}
