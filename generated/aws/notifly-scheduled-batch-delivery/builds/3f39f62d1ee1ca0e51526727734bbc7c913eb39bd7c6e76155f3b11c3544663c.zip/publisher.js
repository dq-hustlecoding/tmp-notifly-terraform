/*
This code is a starter template and will be replaced. 
This code may not be used in production currently.
*/
const { SQSClient, SendMessageCommand, ReceiveMessageCommand, DeleteMessageCommand } = require("@aws-sdk/client-sqs");
const { DynamoDB, GetItemCommand } = require('@aws-sdk/client-dynamodb');
const { marshall, unmarshall } = require('@aws-sdk/util-dynamodb');

exports.handler = async (event) => {
    console.log('Publisher lambda: Testing terraformer-generated lambda');
    console.log(`Received event: ${JSON.stringify(event, null, 2)}`);

    // Handle event from SQS and write to SQS queue

    // Create an instance of the SQS client
    const sqs = new SQSClient({ region: 'ap-northeast-2' });

    // Set the parameters for the SQS scheduler-to-publisher queue
    const scheduler_to_publisher_queue_params = {
        QueueUrl: process.env.SQS_SCHEDULER_TO_PUBLISHER_QUEUE_URL, // the URL of the SQS queue
        MaxNumberOfMessages: 10, // the maximum number of messages to retrieve
        WaitTimeSeconds: 3 // the time to wait for messages in the queue
    };

    // Receive messages from the SQS queue
    const data = await sqs.send(new ReceiveMessageCommand(scheduler_to_publisher_queue_params));

    // Check if there are any messages in the queue
    if (data.Messages) {
        // Process the messages
        data.Messages.forEach(async (message) => {
            // Deserialize the message body
            const event = JSON.parse(message.Body);

            // Do something with the event data
            console.log(`Received event from SQS: ${JSON.stringify(event, null, 2)}`);

            // Delete the message from the queue
            const deleteParams = {
                QueueUrl: scheduler_to_publisher_queue_params.QueueUrl,
                ReceiptHandle: message.ReceiptHandle
            };
            try {
                const data = await sqs.send(new DeleteMessageCommand(deleteParams));
                console.log("Message deleted", data);
            } catch (err) {
                console.log("Error", err);
            }
        });
    } else {
        console.log("No messages to delete");
    }

    // Query user table
    const ddbClient = new DynamoDB({ region: 'ap-northeast-2' });
    const dbparams = {
        TableName: 'test-user',
        Key: marshall({ 'id': 'em068EleAcF/t3Pav+gROFoVbC12WD3aKRPLGWFjyqWb/icM7BVn9ubzfQK+o/1gbnn4/bdL5AkH8MlA4J5zkA==' }),
    };
    const body = await ddbClient.send(new GetItemCommand(dbparams));
    if (body && body.Item) {
        console.dir(unmarshall(body.Item));
    }

    // Set the parameters for the SQS push queue
    const push_queue_params = {
        QueueUrl: process.env.SQS_PUSH_QUEUE_URL, // the URL of the SQS queue
        MessageBody: JSON.stringify({
            name: 'publisher_health_check'
        }) // the data to be written to the queue
    };

    // Send a message to the SQS queue
    const pushData = await sqs.send(new SendMessageCommand(push_queue_params));
    console.log("Success, message sent. MessageID:", pushData.MessageId);
    return pushData; // For unit tests.
}
