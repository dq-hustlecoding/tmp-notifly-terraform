/*
This code is a starter template and will be replaced. 
This code may not be used in production currently.
*/
const { SQSClient, ReceiveMessageCommand, DeleteMessageCommand } = require("@aws-sdk/client-sqs");

exports.handler = async () => {
    console.log('Delivery lambda: Testing terraformer-generated lambda');

    // Create an instance of the SQS client
    const sqs = new SQSClient({ region: 'ap-northeast-2' });

    // Set the parameters for the SQS queue
    const params = {
        QueueUrl: process.env.SQS_PUSH_QUEUE_URL, // the URL of the SQS queue
        MaxNumberOfMessages: 10, // the maximum number of messages to retrieve
        WaitTimeSeconds: 3 // the time to wait for messages in the queue
    };

    // Receive messages from the SQS queue
    const data = await sqs.send(new ReceiveMessageCommand(params));

    // Check if there are any messages in the queue
    if (data.Messages) {
        // Process the messages
        data.Messages.forEach(async (message) => {
            // Deserialize the message body
            const event = JSON.parse(message.Body);

            // Do something with the event data
            console.log(`Received event from SQS: ${JSON.stringify(event, null, 2)}`);

            // Delete the message from the queue
            const deleteParams = {
                QueueUrl: params.QueueUrl,
                ReceiptHandle: message.ReceiptHandle
            };
            try {
                const data = await sqs.send(new DeleteMessageCommand(deleteParams));
                console.log("Message deleted", data);
            } catch (err) {
                console.log("Error", err);
            }
        });
    } else {
        console.log("No messages to delete");
    }

    // Return a success message
    return { message: 'Successfully processed messages from SQS queue' };

}
