/*
This code is a starter template and will be replaced. 
This code may not be used in production currently.
*/
const { SQSClient, SendMessageCommand } = require("@aws-sdk/client-sqs");
const { DynamoDB, GetItemCommand } = require('@aws-sdk/client-dynamodb');
const { marshall, unmarshall } = require('@aws-sdk/util-dynamodb');

exports.handler = async () => {
    console.log('Scheduler lambda: Testing terraformer-generated lambda')

    // Create an instance of the SQS client
    const sqs = new SQSClient({ region: 'ap-northeast-2' });

    // Set the parameters for the SQS queue
    const params = {
        QueueUrl: process.env.SQS_SCHEDULER_TO_PUBLISHER_QUEUE_URL, // the URL of the SQS queue
        MessageBody: JSON.stringify({
            name: 'scheduler_health_check'
        }) // the data to be written to the queue
    };

    // Query campaign table
    const ddbClient = new DynamoDB({ region: 'ap-northeast-2' });
    const dbparams = {
        TableName: 'campaign',
        Key: marshall({ 'id': '1f7c4d9f-3e0e-407e-88a5-c52e1bcf6cab' }),
    };
    const body = await ddbClient.send(new GetItemCommand(dbparams));
    if (body && body.Item) {
        return unmarshall(body.Item);
    }

    // Send a message to the SQS queue
    const data = await sqs.send(new SendMessageCommand(params));
    console.log("Success, message sent. MessageID:", data.MessageId);
    return data; // For unit tests.
}
